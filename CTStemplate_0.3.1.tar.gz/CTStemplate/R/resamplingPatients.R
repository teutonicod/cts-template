resamplingPatients <-
function(myPatients=100,myDoses=0,myTimes,myStudyType,myHeader="ID",
                       myCovariatesNames,myDataset,covariatePath=getwd(),writeFile=TRUE,newDatasetName="myTrial.csv"){ 

                  require(MSToolkit)
                  myTreatments <- length(myDoses)
                  myCovariates <- createExternalCovariates(myPatients,names=myCovariatesNames, file=myDataset,
                                                           workingPath=covariatePath,idCol = myHeader) 


                  myCreateTreatment <- createTreatments(doses = myDoses, times = myTimes, type= myStudyType)

                  myAllocateTreatment <- allocateTreatments(trts = myTreatments, subjects = myPatients, ordered = FALSE, idCol = myHeader)

                  myTrial <- merge(myAllocateTreatment, myCreateTreatment, by="TRT")

                  myTrial <- merge(myTrial, myCovariates, by=myHeader)

                  myTrial <- myTrial[order(myTrial$ID,myTrial$TIME,myTrial$DOSE),]
                  
                  if (writeFile) {write.csv(myTrial, newDatasetName, row.names=FALSE, quote=FALSE)} else return(myTrial)

}

