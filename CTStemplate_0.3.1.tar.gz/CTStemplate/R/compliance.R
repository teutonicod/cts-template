compliance <-
function(data=NULL,readFile=TRUE,prob=c(0.5,0.5),changeDose=TRUE,dose=0,writeFile=TRUE,newDatasetName="myDatasetCompl.csv"){
                if(is.null(data)) stop("Error: data must be provide!")                        

                if(readFile) myData <- read.csv(data) else myData <- data
                
                myData$COMPLIANCE <- 0
                n <- length(myData$COMPLIANCE[myData$EVID==1])
                myVec <- sample(c(0,1),n,prob=prob,replace=TRUE)
                myData$COMPLIANCE[myData$EVID==1] <- myVec
                if(changeDose) myData$DOSE[myData$COMPLIANCE==1] <- dose
                if (writeFile) {
                               write.csv(myData, newDatasetName, row.names = FALSE, quote = FALSE)
                                     }
                       else return(myData)

}

