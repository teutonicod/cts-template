checkForNumeric <-
function(myD,verbose=TRUE){

                              nCol <- c(1:ncol(myD))
                              c <- 0
                              for (i in nCol){
                                         myClass <- class(myD[,nCol[i]])
                                         if(myClass!="numeric" & myClass!="integer" ){ c<-c+1
                                         if (verbose) print(paste("Values in column",i,"are not numeric",sep=" "))}
                                            }
                              if(c==0&verbose) return("All the values in the dataset are numeric")
                              if (!verbose) return(c)
}

