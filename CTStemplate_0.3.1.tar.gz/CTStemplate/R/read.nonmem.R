read.nonmem <-
function (file, header = TRUE, sep = "", na.strings = "NA", skip = 1, ...) {
                                                  
                                                   d <- readLines(file)
                                                   if (skip > 0) 
                                                        d <- d[-(1:skip)]
                                                   if (skip < 0) 
                                                   warning("Invalid (negative) skip value ignored!")
                                                   pos <- grep("^TABLE NO", d)
                                                   if (length(pos) > 0) 
                                                        d <- d[-pos]
                                                   if (header) {
                                                              hea <- d[1]
                                                              d <- d[-grep(hea, d, fixed = TRUE)]
                                                              d <- c(hea, d)
                                                               }
                                                    new_filename <- tempfile()
                                                    writeLines(d, new_filename)
                                                    dd <- read.table(new_filename, header = header, sep = sep, 
                                                    na.strings = na.strings, skip = 0, ...)
                                                    return(dd)
}

