findDivisor <-
function(num){
                             k<-1
                             div<-NULL
                             while(k<=num){
                                        r <- num%%k 
                                       if (r == 0) div<-c(div,k)
                                       k <- k+1
                                           }
                             return(div)
}

