readResults <-
function(fileName,nonmemOutput=TRUE,dv,time,dose=NULL,nSim=1,i=NA,delMDV=FALSE,placeboDose=NULL,writeFile=TRUE,newDatasetName="myD.csv",plot=TRUE,sep=","){

           ifelse(nonmemOutput,    
                             d <- read.nonmem(fileName,skip=0),
                             d <- read.csv(fileName,sep=sep))
		
#Replace the dose of 0.1 with 0
               if (!is.null(placeboDose)){ d$DOSE <- replace(d$DOSE, d$DOSE==placeboDose,0)}
			 
               if(delMDV) {d <- d[d$MDV==0,]}

#This part of the script create a column in the dataset defining the
#simulation ID (SID), in the of 
#case of different simulations are performed with NONMEM

               totalRows <- nrow(d)
               mySubjectRows <- totalRows/nSim 		 
               simVec <- c(1:nSim)
#Insert the SID column into the dataset indicating the NONMEM simulation
               d$SID <- rep(simVec,each=mySubjectRows)	


if (!is.null(dose)){ 
             myD <-split(d[[dv]],paste(round(d[[time]]),d[[dose]]))
             myD <- unlist(lapply(myD,median))
             nam <- matrix(unlist(strsplit(names(myD),split="\\s")),nrow=2)
             myD <- data.frame(DOSE=as.numeric(nam[2,]),TIME=as.numeric(nam[1,]),DV=myD,SIM=i)
             names(myD) <- c(dose,time,dv,"SIM")
             myD <- myD[order(myD[[dose]],myD[[time]]),]
} else {
             myD <-split(d[[dv]],round(d[[time]]))
             myD <- unlist(lapply(myD,median))
             nam <- matrix(unlist(strsplit(names(myD),split="\\s")),nrow=1)
             myD <- data.frame(TIME=as.numeric(nam[1,]),DV=myD,SIM=i)
             names(myD) <- c(time,dv,"SIM")
             myD <- myD[order(myD[[time]]),]
}


if (plot){

require(lattice)
              if (!is.null(dose)){ 

                                myPanel <- function(x,y,...){
                                           panel.xyplot(x,y)
                                           median<-tapply(y,x,median)
                                           panel.lines(unique(x),median,col="green",lwd=2)
                                             }

                                 myPlot <-  xyplot(d[[dv]] ~ d[[time]]|factor(d[[dose]]),data=d,panel=myPanel,
                                            main=paste("Simulation",i,sep="-"),xlab=time,ylab=dv)
} else {

                                  myPanel <- function(x,y,...){
                                             panel.xyplot(x,y)
                                             median<-tapply(y,x,median)
                                             panel.lines(unique(x),median,col="green",lwd=2)
                                             }

                                 myPlot <- xyplot(d[[dv]] ~ d[[time]],data=d,panel=myPanel,
                                            main=paste("Simulation",i,sep="-"),xlab=time,ylab=dv)
}

jpeg(paste("Simulation-",i,".jpeg",sep=""),width=400, height=400, pointsize=33)
print(myPlot)
dev.off() 

}

 if (writeFile){ write.csv(myD, newDatasetName, row.names=F, quote=F)
                        } else return(myD)

}

