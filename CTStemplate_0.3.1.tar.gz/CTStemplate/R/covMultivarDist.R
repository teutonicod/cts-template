covMultivarDist <-
function(catD=NULL,contD=NULL,nSub=100,NArm=FALSE,tol=0.05){
                        ###### Check if the data are numeric
                        if (!is.null(catD)) ckNumCat <- checkForNumeric(catD,verbose=FALSE)
                        if (!is.null(contD)) ckNumCont <- checkForNumeric(contD,verbose=FALSE)
                        
                        if (!is.null(contD) & !is.null(catD)){
                                          if (ckNumCat!=0 |ckNumCont!=0) stop("Error: data are not numeric")                        
                          } else {
                                  if (!is.null(contD)){
                                                       if (ckNumCont!=0) stop("Error: data are not numeric")
                                                       }
                                  if (!is.null(catD)){
                                                       if (ckNumCat!=0) stop("Error: data are not numeric")
                                                       }                                
                                  }
                        if(NArm) {

                                   if (is.null(catD))  myD <- data.frame(contD)
                                   if (is.null(contD))  myD <- data.frame(catD)
                                   if (!is.null(contD) & !is.null(catD))  myD <- data.frame(catD,contD)                               
                                   if (is.null(contD) & is.null(catD)) stop(" ERROR: At least one dataframe must be provided")
                                   myD <- removeNA(myD)
                                   myDCol <- ncol(catD)
                                   catD <- myD[,1:myDCol] 
                                   contD <- myD[,(myDCol+1):ncol(myD)]
                                  }

                         ########### Combine the dataset together
                         if (is.null(catD))  myD <- data.frame(contD)
                         if (is.null(contD))  myD <- data.frame(catD)
                         if (!is.null(contD) & !is.null(catD))  myD <- data.frame(catD,contD)                               
                         if (is.null(contD) & is.null(catD)) stop(" ERROR: At least a dataframe must be provided")

                         ########### Find the total number of covariates that we need to simulate
                         ##########  This corresponts to the munimum number of patients that we can simulate 
                         myCovariates <- ncol(myD)
                         ######### Find the number of divisor of the patients that we want simulate and
                         ######### find the smaller divisor greater than the number of covariates
                         myDivisors <- findDivisor(nSub)
                         myDivisors <- myDivisors[myDivisors>=myCovariates]

                         ######### Find the number of patients that can be simulated at 
                         ######### every cycle being above of the munimun number allowed
                         myPatNum <- myDivisors[1]
                         ######### This is the number of cycles of simulations needed to 
                         ######### obtained the desired population
                         cycles <- nSub/myPatNum
                         j<-0
                         while(j<cycles){


                                         ###### Convert the dataset in logDataset adding one to covariates
                                         if (!is.null(catD)) logCatD <- log(catD+1)
                                         if (!is.null(contD)) logContD <- log(contD)

                                          ##### Combine togheter the datasets  
                                          if (is.null(catD))  myLogD <- data.frame(logContD)
                                          if (is.null(contD))  myLogD <- data.frame(logCatD)
                                          if (!is.null(contD) & !is.null(catD))  myLogD <- data.frame(logCatD,logContD)                     

                                         ##### Compute means and covariance in the log space
                                         myLogDMeans <- apply(myLogD,2,mean,na.rm=TRUE)
                                         myLogCovariance <- cov(myLogD,use="complete.obs" )

                                         ##### Simulate n subject from the multivariate distribution                        
                                         simCovariatesLog <- as.data.frame(mvrnorm(myPatNum,myLogDMeans,myLogCovariance,empirical=TRUE))

                                         ##### Find the number of columns in the initial cetegorical dataset 
                                         
                                         myCol <- ifelse(!is.null(catD), ncol(catD),0)
                                         
                                         myNames <- names(simCovariatesLog)
                                         
                                         ##### Divide the simulated dataset between categorical and continous
                                         if (!is.null(catD)) {
                                                            logSimCatD <- as.data.frame(simCovariatesLog[,1:myCol])
                                                            names(logSimCatD) <- myNames[1:myCol]
                                                            }
                                         if (!is.null(contD)){
                                                            logSimContD <- as.data.frame(simCovariatesLog[,(myCol+1):ncol(simCovariatesLog)])
                                                            names(logSimContD) <- myNames[(myCol+1):ncol(simCovariatesLog)]
                                                             }
                                         ##### Convert values in exponential (substracting 1 to cat covariates)
                                        if (!is.null(catD)) simCatD <- exp(logSimCatD)-1
                                        if (!is.null(contD)) simContD <- exp(logSimContD)
                   

                                        #######  Compute the cutoff for categorical covariates in order 
                                        #######  to divide the continous values simulated from the distribution
                                        #######  According to the article: 
                                        ####  Tannenbaum et al. Simulation of correlated continous and categorical
                                        ####  variables using a single multivariate distribution
                                        ####  J Pharmacokinetics and Pharmacodynamics, vol.33 N.6, 2006

                                        if (!is.null(catD)){
                                                for (i in 1:myCol){

                                                           #### Mean and sd from the empirical distribution
                                                           myMean <- mean(logCatD[,i],na.rm=TRUE)
                                                           mySd <- sd(logCatD[,i],na.rm=TRUE)
                        
                                                           myLevels <- sort(unique(exp(logCatD[,i])))-1

                                                           ##### Compute the cumulative probability for the 
                                                           ##### different levels of the covariate 
                                                           myVar <- as.data.frame(table(catD[,i]))
                                                           myVar$tot <- sum(myVar$Freq)
                                                           myVar$perc <- myVar$Freq/myVar$tot
                                                           myVar$cumPerc <- cumsum(myVar$perc)

                                                           ###### Measure the invers of the log normal distribution                        
                                                           #####   This cutoff refers to the real values, not in the log space
                                                           myCutoff <- qlnorm(myVar$cumPerc, mean=myMean, sd=mySd)-1

                                                           ### Add -Inf as lower limit of the cutoff
                                                           myCutoff <- c(-Inf,myCutoff)

                                                           #### Replace the continous simulated data to categorical data 
                                                           simCatD[,i] <- cut(simCatD[,i],myCutoff,include.lowest=TRUE,labels=myLevels)
                                                           }
                                                    }


                                        ##### Combine togheter the datasets  
                                        if (is.null(catD))  mySimDataset <- cbind(simContD)
                                        if (is.null(contD))  mySimDataset <- cbind(simCatD)
                                        if (!is.null(contD) & !is.null(catD))  mySimDataset <- cbind(simCatD,simContD)


                                        ####### Condition for the contiuous covariates
                                        if (!is.null(contD)){
                                        minSimCont <- lapply(as.data.frame(mySimDataset[,(myCol+1):ncol(mySimDataset)]),min,na.rm=TRUE)
                                        minRealCont <- lapply(contD,min,na.rm=TRUE)
                                        minCond <- unlist(minSimCont) - unlist(minRealCont)>0 
                                        
                                        maxSimCont <- lapply(as.data.frame(mySimDataset[,(myCol+1):ncol(mySimDataset)]),max,na.rm=TRUE)
                                        maxRealCont <- lapply(contD,max,na.rm=TRUE)
                                        maxCond <- unlist(maxSimCont) - unlist(maxRealCont)<0 
                                                                                
                                        contCond <- c(minCond,maxCond)
                                        } else contCond <- TRUE

                                        if (all(contCond)){
                                                          if(j==0) mySimD<-mySimDataset else mySimD<-rbind(mySimD,mySimDataset)
                                                          j<-j+1
                                                          }
                          }


                         if (!is.null(catD)){
                                     mySimCatCov <- as.data.frame(mySimD[,1:myCol])
                                     names(mySimCatCov) <-  myNames[1:myCol]

                                     ############### Check if the categorical covariates in the final dataset 
                                     ############### keep the proportion of the original datasert
                                     s1 <- lapply(mySimCatCov,table)
                                     s2 <- lapply(s1,function(x) x/sum(x))
                                     s3 <- lapply(catD,table)
                                     s4 <- lapply(s3,function(x) x/sum(x))
                                     dif <- mapply("-",s2,s4)
                                     difl <- sapply(dif,function(x) any(abs(x)>tol))
                                     con <- any(difl)
                                   } else con <- FALSE
                        
                          if(con) covMultivarDist(catD=catD,contD=contD,nSub=nSub,NArm=NArm,tol=tol)


                          return(mySimD)


}

