removeNA <-
function(d){
                       c <- checkForNA(d,verbose=F)
                       w1 <- which(sapply(d,function(x) any(is.na(x))))
                       if(c!=0) {
                                for (nam in names(w1)) d <- d[!is.na(d[,nam]),]
                                return(d)
                                } else return(d)                                           
}

