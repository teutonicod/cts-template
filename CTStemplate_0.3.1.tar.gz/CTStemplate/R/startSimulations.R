startSimulations <-
function (n = 3, startingSeed = 100, filesToCopy = NULL, scriptToExeute =NULL){
    
    myPath <- getwd()
    mySimID <- 1
    for (mySimID in 1:n) {
                          set.seed(startingSeed + mySimID)
                          dir.create(paste("Simulation", mySimID, sep = "-"))                       

                          if(!is.null(filesToCopy)) file.copy(filesToCopy, 
                                                              paste("Simulation", mySimID, sep = "-"), 
                                                              overwrite = FALSE, recursive = FALSE,
                                                              copy.mode = TRUE)

                           setwd(paste("Simulation", mySimID, sep = "-"))
                           source(file=paste(myPath,scriptToExeute,sep="/"))
                           setwd(myPath)
                           }
     print("End of the Simulations")
}





