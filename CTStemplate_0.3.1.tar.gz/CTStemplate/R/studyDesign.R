studyDesign <-
function(myPatients=100,myDoses=0,myTimes,myStudyType,
                       writeFile=TRUE,newDatasetName="myTrial.csv"){

                       require(MSToolkit)

                       myTreatments <- length(myDoses)

                       myCreateTreatment <- createTreatments(doses = myDoses, times = myTimes, type= myStudyType)

                       myAllocateTreatment <- allocateTreatments(trts = myTreatments, subjects = myPatients, ordered = FALSE, idCol = "ID")

                       myTrial <- merge(myAllocateTreatment, myCreateTreatment, by="TRT")

                       myTrial <- myTrial[order(myTrial$ID,myTrial$TIME,myTrial$DOSE),]

                       if (writeFile) {
                                     write.csv(myTrial, newDatasetName, row.names = FALSE, quote = FALSE)
                                     }
                       else return(myTrial)
}

