dataFormattingGUI <-
function(){

                      require(tcltk)
                      require(tcltk2)

       

        fontHeading <- tkfont.create(family="times",size=18,weight="bold",slant="italic")
        fontTextLabel <- tkfont.create(family="times",size=12)

        ######  Labels Study Design
        ADDL <- "Additional Doses (ADDL)"
        inComp <- "Compartments to Initialize"  
        II <- "Interval of Administration (II)"
        inAm <- "Initial Amount"
        placeboD <- "Replace Placebo Doses"
        DVcompartment <- "Compartments for observations"

        dataset <- "Name of the dataset"
        
        myVar <- list("NULL","","NULL","","NULL","","","","","","","","","","","","")

        dlg <- tktoplevel()
        
        tkgrab.set(dlg)
  
        tkwm.title(dlg,"Formatting of the Dataset for NONMEM")
        
        title1 <- tklabel(dlg,text="Formatting of the Dataset for NONMEM",font=fontHeading)

        #### Definition tkentry
        #### ADDL
        textEntryADDL <- tclVar(paste(myVar[[1]]))
        textEntryWidgetADDL <- tk2entry(dlg,width=15,textvariable=textEntryADDL)
        ADDLTkLabel <- tk2label(dlg,text=ADDL)

        #### inComp
        textEntryInComp <- tclVar(paste(myVar[[2]]))
        textEntryWidgetInComp <- tk2entry(dlg,width=15,textvariable=textEntryInComp)
        inCompTkLabel <- tk2label(dlg,text=inComp)
 
        #### II
        textEntryII  <- tclVar(paste(myVar[[3]]))
        textEntryWidgetII  <- tk2entry(dlg,width=15,textvariable=textEntryII)
        IITkLabel <- tk2label(dlg,text=II)

        #### initial Amount
        textEntryInAm <- tclVar(paste(myVar[[4]]))
        textEntryWidgetInAm <- tk2entry(dlg,width=15,textvariable=textEntryInAm)
        inAmTkLabel <- tk2label(dlg,text=inAm)

        #### placebo Dose
        textEntryPlaceboD <- tclVar(paste(myVar[[5]]))
        textEntryWidgetPlaceboD <- tk2entry(dlg,width=15,textvariable=textEntryPlaceboD)
        placeboDTkLabel <- tk2label(dlg,text=placeboD)

        #### DVcompartment
        textEntryDVcompartment <- tclVar(paste(myVar[[6]]))
        textEntryWidgetDVcompartment <- tk2entry(dlg,width=15,textvariable=textEntryDVcompartment)
        DVcompartmentTkLabel <- tk2label(dlg,text=DVcompartment)


        #### Include Baseline
        rbYes <- tk2radiobutton(dlg)
        rbNo <- tk2radiobutton(dlg)

        rbValue <- tclVar("FALSE")
        tkconfigure(rbYes,variable=rbValue,value="TRUE")
        tkconfigure(rbNo,variable=rbValue,value="FALSE")
        yesTkLabel <- tk2label(dlg,text="Yes ")
        noTkLabel <- tk2label(dlg,text="No ")

        
        #### Dataset to format
        textEntryDataset <- tclVar(paste(myVar[[7]]))
        textEntryWidgetDataset <- tk2entry(dlg,width=15,textvariable=textEntryDataset)
        datasetTkLabel <- tk2label(dlg,text=dataset)


        tkgrid(title1, column=2,columnspan=2)
        tkgrid.configure(title1,sticky="nsew")
    
        tkgrid(tklabel(dlg,text="       "))

       
        tkgrid(ADDLTkLabel, column=1,columnspan=1,row=2, rowspan=1)
        tkgrid(textEntryWidgetADDL, column=2,columnspan=1,row=2, rowspan=1,padx=5,pady=5)
        tkgrid(inCompTkLabel, column=3,columnspan=1,row=2, rowspan=1)
        tkgrid(textEntryWidgetInComp, column=4,columnspan=1,row=2, rowspan=1,padx=5,pady=5)

        tkgrid.configure(ADDLTkLabel,inCompTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetADDL,textEntryWidgetInComp,sticky="w")
 
 
        tkgrid(IITkLabel, column=1,columnspan=1,row=3, rowspan=1)
        tkgrid(textEntryWidgetII, column=2,columnspan=1,row=3, rowspan=1,padx=5,pady=5)
        tkgrid(inAmTkLabel, column=3,columnspan=1,row=3, rowspan=1)
        tkgrid(textEntryWidgetInAm, column=4,columnspan=1,row=3, rowspan=1,padx=5,pady=5)

        tkgrid.configure(IITkLabel,inAmTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetII,textEntryWidgetInAm,sticky="w")


        tkgrid(placeboDTkLabel, column=1,columnspan=1,row=4, rowspan=1)
        tkgrid(textEntryWidgetPlaceboD, column=2,columnspan=1,row=4, rowspan=1,padx=5,pady=5)
        tkgrid(DVcompartmentTkLabel, column=3,columnspan=1,row=4, rowspan=1)
        tkgrid(textEntryWidgetDVcompartment, column=4,columnspan=1,row=4, rowspan=1,padx=5,pady=5)

        tkgrid.configure(placeboDTkLabel,DVcompartmentTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetPlaceboD,textEntryWidgetDVcompartment,sticky="w")



        baselineLabel <- tklabel(dlg,text="Include time 0 in the simulation")
        tkgrid.configure(baselineLabel,sticky="w")

        tkgrid(baselineLabel, column=2,columnspan=1,row=5,rowspan=2)
        tkgrid(yesTkLabel, column=2,columnspan=1,row=5,rowspan=1)
        tkgrid(rbYes, column=3,columnspan=1,row=5,rowspan=1)
        tkgrid(noTkLabel, column=2,columnspan=1,row=6,rowspan=1)
        tkgrid(rbNo, column=3,columnspan=1,row=6,rowspan=1)

        tkgrid.configure(yesTkLabel,noTkLabel,sticky="e")
        tkgrid.configure(rbYes,rbNo,sticky="w")
   
        tkgrid(tklabel(dlg,text="       "), column=7,columnspan=1,row=8,rowspan=1)


        getName <- function(){
                      #if(exists("myPath")){ remove(myPath)}
                      myChoose <- file.choose()
                      myFile <- basename(myChoose)
                      myPath <- dirname(myChoose)
                      tclvalue(textEntryDataset) <- paste("\"",myFile,"\"",sep="")
                      assign("myPath",myPath,envir=parent.frame())
                      on.exit(tkfocus(dlg))
                      }


        getName.but <- tk2button(dlg,text="  Select file  ",command=getName)


        tkgrid(datasetTkLabel, column=1,columnspan=1,row=9,rowspan=1)
        tkgrid(textEntryWidgetDataset, column=2,columnspan=1,row=9,rowspan=1,padx=5,pady=5)
        tkgrid(getName.but, column=3,columnspan=1,row=9,rowspan=1)
        tkgrid.configure(datasetTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetDataset,sticky="we")
        tkgrid.configure(getName.but,sticky="w")





         onCancel <- function()tkdestroy(dlg)

         mySim <- function(){            

                             baseline <- as.character(tclvalue(rbValue))           
                                   
                             eval(parse(text=paste("myADDL <-",tclvalue(textEntryADDL))))
                             eval(parse(text=paste("myII <-",tclvalue(textEntryII))))
                             eval(parse(text=paste("nComp <-",tclvalue(textEntryInComp))))
                             eval(parse(text=paste("inAMT <-",tclvalue(textEntryInAm))))
                             eval(parse(text=paste("placeboDose <-",tclvalue(textEntryPlaceboD))))
                             eval(parse(text=paste("DVcomp <-",tclvalue(textEntryDVcompartment))))

                             eval(parse(text=paste("includeBaseline <-\"",baseline,"\"",sep="")))
                             #if (tclvalue(textEntryCovariatesNames)!="") eval(parse(text=paste("myCovariatesNames <-",tclvalue(textEntryCovariatesNames))))
                             eval(parse(text=paste("myDataset <-",tclvalue(textEntryDataset))))
                             #if (tclvalue(textEntryCatD)!="") eval(parse(text=paste("catNames <-",tclvalue(textEntryCatD))))
                             #if (tclvalue(textEntryContD)!="") eval(parse(text=paste("contNames <-",tclvalue(textEntryContD))))

                             datasetPath <- ifelse(exists("myPath"),  myPath, getwd())

                      dataFormatting(myADDL=myADDL,myII=myII,nComp=nComp,DVcomp=DVcomp,inAMT=inAMT,includeBaseline=includeBaseline,
                      myDataset=myDataset,readFile=TRUE,writeFile=TRUE,newDatasetName="myDataset.csv",placeboDose=NULL,datasetPath=datasetPath)

                            
          print("Simulation completed!")                         

          }





         myPrev <- function(){                

                             baseline <- as.character(tclvalue(rbValue))           
                                   
                             eval(parse(text=paste("myADDL <-",tclvalue(textEntryADDL))))
                             eval(parse(text=paste("myII <-",tclvalue(textEntryII))))
                             eval(parse(text=paste("nComp <-",tclvalue(textEntryInComp))))
                             eval(parse(text=paste("inAMT <-",tclvalue(textEntryInAm))))
                             eval(parse(text=paste("placeboDose <-",tclvalue(textEntryPlaceboD))))
                             eval(parse(text=paste("DVcomp <-",tclvalue(textEntryDVcompartment))))

                             eval(parse(text=paste("includeBaseline <-\"",baseline,"\"",sep="")))
                             #if (tclvalue(textEntryCovariatesNames)!="") eval(parse(text=paste("myCovariatesNames <-",tclvalue(textEntryCovariatesNames))))
                             eval(parse(text=paste("myDataset <-",tclvalue(textEntryDataset))))
                             #if (tclvalue(textEntryCatD)!="") eval(parse(text=paste("catNames <-",tclvalue(textEntryCatD))))
                             #if (tclvalue(textEntryContD)!="") eval(parse(text=paste("contNames <-",tclvalue(textEntryContD))))

                             datasetPath <- ifelse(exists("myPath"),  myPath, getwd())

                         myStudyPreview <- dataFormatting(myADDL=myADDL,myII=myII,nComp=nComp,DVcomp=DVcomp,inAMT=inAMT,includeBaseline=includeBaseline,
                      myDataset=myDataset,readFile=TRUE,writeFile=FALSE,placeboDose=NULL,datasetPath=datasetPath)                                            

         fix(myStudyPreview,edit.row.names=FALSE) 
         on.exit(tkfocus(dlg))
         }



         prev.but <- tk2button(dlg,text="  Dataset preview  ",command=myPrev)
         sim.but     <-tk2button(dlg,text="  Simulate study   ",command=mySim)
         Cancel.but <-tk2button(dlg,text=" Cancel ",command=onCancel)
         

         tkgrid(tklabel(dlg,text="       "))
         tkgrid(prev.but, column=2,columnspan=1,row=17, rowspan=1)
         tkgrid(sim.but, column=3,columnspan=1,row=17, rowspan=1)
         tkgrid(Cancel.but, column=4,columnspan=1,row=17, rowspan=1)

         tkgrid(tklabel(dlg,text="       "))



#########################  Tooltips
  tk2tip(ADDLTkLabel, message="Number of additional doses \n\nAllows a single numeric value")
  tk2tip(inCompTkLabel, message="Compartments to initialize \n\nAllows a vector in R code (e.g. c(1,2,3))")
  tk2tip(IITkLabel, message="II value for NONMEM\n\nAllows a single numeric value")
  tk2tip(inAmTkLabel, message="Amounts to initialize the compartments \n\nAllows a vector in R code (e.g. c(1,2,3))")
  tk2tip(placeboDTkLabel, message="Value to replace doses equal to 0 \n\nAllows a single numeric value")
  tk2tip(datasetTkLabel, message="Name of the dataset .csv which must be formatted")
  tk2tip(DVcompartmentTkLabel, message="Compartments where the DV is observed \n\nAllows a vector in R code (e.g. c(1,2,3))")


tkfocus(dlg)
invisible(tkwm.deiconify(dlg))

}

