dataFormatting <-
function(myADDL=NULL,myII=NULL,nComp,DVcomp,inAMT,includeBaseline=FALSE,myDataset,
                           readFile=TRUE,writeFile=TRUE,newDatasetName="myDataset.csv",placeboDose=NULL,datasetPath=getwd()){

       myPath <- getwd()
       setwd(datasetPath)
                      if(readFile){
                             myTrial <- read.csv(myDataset,header=TRUE)  # Read the dataset from file
                             } else myTrial <- myDataset                  # or a dataset must be provided
       setwd(myPath)


#Replace the doses = 0 to doses of 0.1 since NONMEM VI do not accept null doses

                      if (!is.null(placeboDose)) {
                            myTrial$DOSE[myTrial$DOSE==0] <- placeboDose
                            }

#This part of the script add additional column necessary for the NONMEM file
                           myTrial$DV <- "."
                           myTrial$AMT <- "."
                           if (!is.null(myADDL)) myTrial$ADDL <- 0
                           if (!is.null(myII))  myTrial$II <- 0
                           myTrial$EVID <- 0
                           myTrial$CMT <- NA
                           myTrial$MDV <- 0

	

                           mat1 <- match(unique(myTrial$ID),myTrial$ID)
                           i<-1
                           for (i in 1:length(nComp)){
                                          myComp <- mat1
                                          if (i == 1) matX <- myComp else matX <- c(matX,myComp)  
                                          #mat2 <- sort(c(matX,1:nrow(myTrial)))
                                          if (includeBaseline) mat2<-sort(c(matX,matX)) else mat2<-sort(matX) 
                            }


                            myDataset <- myTrial[mat2,]                          
                            myDVdataset <- myTrial[-mat1,]

                            for (i in 1:length(DVcomp)){
                                          myDVdataset$CMT <- DVcomp[i]
                                          if (i==1) myD <- myDVdataset else myD <- rbind(myD,myDVdataset)
                                          }
                            myDataset <- rbind(myDataset,myD)

                            if ("TRT"%in%names(myDataset)){
                                             myDataset <- myDataset[order(myDataset$ID,myDataset$TIME,myDataset$CMT,myDataset$TRT),]
                            } else myDataset <- myDataset[order(myDataset$ID,myDataset$TIME,myDataset$CMT),]



#In this part of the script are added the value into columns and rows 
#added to the initial dataset

#Define the match for the first element of the new dataset
                          mat3 <- match(unique(myDataset$ID),myDataset$ID)

#Add the dose value in EVID

                          i<-1
                          for (i in 1:length(nComp)){
#Add the EVID value
                                          myDataset$EVID[mat3+i-1] <- 1  
                          }


###############  Compartment number
                          i<-1
                          for (i in 1:length(nComp)){
                                         #Add the compartment value in CMT
                                         myDataset$CMT[mat3+i-1] <- nComp[i]
                          }

###############  Compartment number for repeated time 0
                         if (includeBaseline){ i<-1
                                      for (i in 1:length(nComp)){
                                                      #Add the compartment value in CMT for repeated time 0
                                                      myDataset$CMT[mat3+length(nComp)+i-1] <- nComp[i]
                                         }
                         }

######  Initialization of the compartments

                          i<-1
                          for (i in 1:length(nComp)){
                                           #Add the initial value in AMT
                                           myDataset$AMT[mat3+i-1] <- inAMT[i]
                           }

####  The string value "d" representing the dose is sunstituted by the dose
                           myDataset$AMT[myDataset$AMT=="d"] <- myDataset$DOSE[myDataset$AMT=="d"]


#Add the dose value in MDV
                          for (i in 1:length(nComp)){ 
                                           myDataset$MDV[mat3+i-1] <- 1
                             }

#Add the dose value in ADDL
         if (!is.null(myADDL))    myDataset$ADDL[mat3] <- myADDL


#Add the dose value in II
         if (!is.null(myII))    myDataset$II[mat3] <- myII


#Write the formatted datacet
                       if (writeFile){ write.csv(myDataset, newDatasetName, row.names=FALSE, quote=FALSE)
                        } else return(myDataset)

}

