runNonmem <-
function(nonmemModel,changeSeed=TRUE,i=1,deleteFiles=FALSE,fileToDelete,commandToExecute="execute -clean=1",appendModel=TRUE){

                        if(changeSeed){
                        myModel <- readLines(nonmemModel)
#The NONMEM seed must be changed, so the seed of the NONMEM file selected will be incremented
#by the value of i that change at every simulation.
#This give also the possibility to repeate the simulation performed
#Find the position where the seed is
                                  pos <- grep('\\$SIM',myModel)

#Select the original seed as vector of seeds
                                  oseed <- strsplit(myModel[pos],"[[:upper:]]|[[:punct:]]|\\s|=.+")
                                  oseed <- unlist(oseed)
                                  oseed <- oseed[oseed!=""]
                                  oseed <- as.numeric(oseed)
                                  

                                  
#Define the new seed as vector of seeds
                                  nseed <- oseed+i
#Replace the seeds
                                  myString <- myModel[pos]
                                  for (k in 1:length(oseed)){
                                                   myString <- gsub(oseed[k],nseed[k],myString)                   

                                  }                
                               
                                  myModel[pos] <- myString

                                  writeLines(myModel,nonmemModel)
                                  }

#Add the NONMEM file choosed for the simulations with the seed changed
                                             
			  
#Run NONMEM with the new created dataset
	                 if (appendModel) SHELL(paste(commandToExecute, nonmemModel, sep=" "))
                       else SHELL(commandToExecute)

                     if(deleteFiles){
                                     for (j in 1:length(fileToDelete)){
                                                unlink(fileToDelete[j], recursive=T)
                                                                      }
                                    }
}
