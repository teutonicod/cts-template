SHELL <-
function (cmd, shw = FALSE, invis = FALSE) 
{
    if (length(grep("Windows", Sys.info()["sysname"], ignore.case = "TRUE")) < 
        1) 
        system(cmd)
    else system(paste(Sys.getenv("COMSPEC"), "/c", cmd), show.output.on.console = shw, 
        invisible = invis)
}

