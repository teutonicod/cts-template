checkForNA <-
function(d,verbose=TRUE){
                         c <-0
                         if(any(is.na(d))){
                                    w1 <- which(sapply(d,function(x) any(is.na(x))))
                                    c<-c+length(w1)
                                    if (verbose) {
                                                 print("The dataset contains NA values")
                                                 print(w1)
                                                 } else return(c)
                                           } 
                         else if (verbose) print("The dataset do not contains NA values")
                              else return(c)
}

