patientSimulationGUI <-
function(){

                      require(tcltk)
                      require(tcltk2)

       

        fontHeading <- tkfont.create(family="times",size=18,weight="bold",slant="italic")
        fontTextLabel <- tkfont.create(family="times",size=12)

        ######  Labels Study Design
        patients <- "Number of patients"
        times <- "Sample times"  
        doses <- "Doses"
        IDs <- "Subject column header"

        ######  Labels Patients Simulation
        covariatesNames <- "Header of the covariates to sample"
        dataset <- "Name of the dataset"  
        CatD <- "Categorical covariates"
        ContD <- "Continuous covariates"

        myVar <- list("","","","","","","","","","","","","","","","","","")

        dlg <- tktoplevel()
        
        tkgrab.set(dlg)
  
        tkwm.title(dlg,"Patient Simulation and Study Design GUI")
        
        title1 <- tklabel(dlg,text="Study design",font=fontHeading)

        #### Definition tkentry
        #### Patients
        textEntryPatients <- tclVar(paste(myVar[[1]]))
        textEntryWidgetPatients <- tk2entry(dlg,width=15,textvariable=textEntryPatients)
        patTkLabel <- tk2label(dlg,text=patients)

        #### Times
        textEntryTimes <- tclVar(paste(myVar[[2]]))
        textEntryWidgetTimes <- tk2entry(dlg,width=15,textvariable=textEntryTimes)
        timeTkLabel <- tk2label(dlg,text=times)
 
        #### Doses
        textEntryDoses <- tclVar(paste(myVar[[4]]))
        textEntryWidgetDoses <- tk2entry(dlg,width=15,textvariable=textEntryDoses)
        doseTkLabel <- tk2label(dlg,text=doses)

        #### IDs
        textEntryIDs <- tclVar(paste(myVar[[5]]))
        textEntryWidgetIDs <- tk2entry(dlg,width=15,textvariable=textEntryIDs)
        IDsTkLabel <- tk2label(dlg,text=IDs)
 
        #### Study design
        rbParallel <- tk2radiobutton(dlg)
        rbCrossover <- tk2radiobutton(dlg)

        rbValue <- tclVar("Parallel")
        tkconfigure(rbParallel,variable=rbValue,value="Parallel")
        tkconfigure(rbCrossover,variable=rbValue,value="Crossover")
        parTkLabel <- tk2label(dlg,text="Parallel ")
        crossTkLabel <- tk2label(dlg,text="Crossover ")

        ##########  Patient simulation
        title3 <- tklabel(dlg,text="Patients Simulation",font=fontHeading)

        #### Patient Simulation
        rbResampling <- tk2radiobutton(dlg)
        rbMultivariate <- tk2radiobutton(dlg)

        rbValue2 <- tclVar("NULL")
        tkconfigure(rbResampling,variable=rbValue2,value="Resampling")
        tkconfigure(rbMultivariate,variable=rbValue2,value="Multivariate")
        risTkLabel <- tk2label(dlg,text="Resampling ")
        multiTkLabel <- tk2label(dlg,text="Multivariate ")

        #  ###################  Resampling
        #### Covariate Names
        textEntryCovariatesNames <- tclVar(paste(myVar[[10]]))
        textEntryWidgetCovariatesNames <- tk2entry(dlg,width=55,textvariable=textEntryCovariatesNames)
        covTkLabel <- tk2label(dlg,text=covariatesNames)

        #### Dataset
        textEntryDataset <- tclVar(paste(myVar[[11]]))
        textEntryWidgetDataset <- tk2entry(dlg,width=15,textvariable=textEntryDataset)
        datasetTkLabel <- tk2label(dlg,text=dataset)

        ###########  Multivariate distribution
        ######  Categorical Covariates
        textEntryCatD <- tclVar(paste(myVar[[12]]))
        textEntryWidgetCatD <- tk2entry(dlg,width=15,textvariable=textEntryCatD)
        catDTkLabel <- tk2label(dlg,text=CatD)
  
        ######  Continuous Covariates
        textEntryContD <- tclVar(paste(myVar[[13]]))
        textEntryWidgetContD <- tk2entry(dlg,width=15,textvariable=textEntryContD)
        contDTkLabel <- tk2label(dlg,text=ContD)

        tkgrid(title1, column=2,columnspan=2)
        tkgrid.configure(title1,sticky="nsew")
    
        tkgrid(tklabel(dlg,text="       "))

        #textTitle1 <- tklabel(dlg,text="Here you can include the parameters of the study design",font=fontTextLabel)


        #tkgrid(textTitle1, column=0,columnspan=6,row=1, rowspan=1)

        tkgrid(patTkLabel, column=1,columnspan=1,row=2, rowspan=1)
        tkgrid(textEntryWidgetPatients, column=2,columnspan=1,row=2, rowspan=1,padx=5,pady=5)
        tkgrid(timeTkLabel, column=3,columnspan=1,row=2, rowspan=1)
        tkgrid(textEntryWidgetTimes, column=4,columnspan=1,row=2, rowspan=1,padx=5,pady=5)

        tkgrid.configure(patTkLabel,timeTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetPatients,textEntryWidgetTimes,sticky="w")
 
 
        tkgrid(doseTkLabel, column=1,columnspan=1,row=3, rowspan=1)
        tkgrid(textEntryWidgetDoses, column=2,columnspan=1,row=3, rowspan=1,padx=5,pady=5)
        tkgrid(IDsTkLabel, column=3,columnspan=1,row=3, rowspan=1)
        tkgrid(textEntryWidgetIDs, column=4,columnspan=1,row=3, rowspan=1,padx=5,pady=5)

        tkgrid.configure(doseTkLabel,IDsTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetDoses,textEntryWidgetIDs,sticky="w")

        studyLabel <- tklabel(dlg,text="Which study do you \nwant to perform?")
        tkgrid.configure(studyLabel,sticky="nsew")

        tkgrid(studyLabel, column=2,columnspan=1,row=4,rowspan=2)
        tkgrid(parTkLabel, column=3,columnspan=1,row=4,rowspan=1)
        tkgrid(rbParallel, column=4,columnspan=1,row=4,rowspan=1)
        tkgrid(crossTkLabel, column=3,columnspan=1,row=5,rowspan=1)
        tkgrid(rbCrossover, column=4,columnspan=1,row=5,rowspan=1)

        tkgrid.configure(parTkLabel,crossTkLabel,sticky="e")
        tkgrid.configure(rbParallel,rbCrossover,sticky="w")
   
        ####### Patient Simulation
        tkgrid(tklabel(dlg,text="       "))

        tkgrid(title3, column=2,columnspan=2,row=7, rowspan=1)
        tkgrid.configure(title3,sticky="nsew")

        simLabel <- tklabel(dlg,text="Method to simulate patients")
        tkgrid.configure(simLabel,sticky="e")

        tkgrid(simLabel, column=0,columnspan=1,row=8,rowspan=2,padx=5,pady=5)

        tkgrid(risTkLabel, column=1,columnspan=1,row=8,rowspan=1)
        tkgrid(rbResampling, column=2,columnspan=1,row=8,rowspan=1)
        tkgrid(multiTkLabel, column=1,columnspan=1,row=9,rowspan=1)
        tkgrid(rbMultivariate, column=2,columnspan=1,row=9,rowspan=1)

        tkgrid.configure(risTkLabel,multiTkLabel,sticky="e")
        tkgrid.configure(rbResampling,rbMultivariate,sticky="w")

        tkgrid(covTkLabel, column=3,columnspan=1,row=8,rowspan=1)
        tkgrid(textEntryWidgetCovariatesNames, column=4,columnspan=3,row=8,rowspan=1,padx=5,pady=5)

        tkgrid(tklabel(dlg,text="       "), column=7,columnspan=1,row=8,rowspan=1)

        tkgrid.configure(rbResampling,textEntryWidgetCovariatesNames,sticky="w")
        tkgrid.configure(risTkLabel,covTkLabel,sticky="e")

        tkgrid(catDTkLabel, column=3,columnspan=1,row=9,rowspan=1)
        tkgrid(textEntryWidgetCatD, column=4,columnspan=1,row=9,rowspan=1,padx=5,pady=5)
        tkgrid(contDTkLabel, column=5,columnspan=1,row=9,rowspan=1)
        tkgrid(textEntryWidgetContD, column=6,columnspan=1,row=9,rowspan=1,padx=5,pady=5)

        tkgrid.configure(catDTkLabel,contDTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetCatD,textEntryWidgetContD,sticky="w")


        getName <- function(){
                      #if(exists("myPath")){ remove(myPath)}
                      myChoose <- file.choose()
                      myFile <- basename(myChoose)
                      myPath <- dirname(myChoose)
                      tclvalue(textEntryDataset) <- paste("\"",myFile,"\"",sep="")
                      assign("myPath",myPath,envir=parent.frame())
                      on.exit(tkfocus(dlg))
                      }


        getName.but <- tk2button(dlg,text="  Select file  ",command=getName)


        tkgrid(datasetTkLabel, column=0,columnspan=1,row=10,rowspan=1)
        tkgrid(textEntryWidgetDataset, column=1,columnspan=1,row=10,rowspan=1,padx=5,pady=5)
        tkgrid(getName.but, column=2,columnspan=1,row=10,rowspan=1)
        tkgrid.configure(datasetTkLabel,sticky="e")
        tkgrid.configure(textEntryWidgetDataset,sticky="w")




         onCancel <- function()tkdestroy(dlg)

         mySim <- function(){

                            # myPatients <- as.numeric(tclvalue(textEntryPatients)) 
                            # myTimes <- as.character(tclvalue(textEntryTimes))        
                            # myDoses <- as.character(tclvalue(textEntryDoses))        
                            # myHeader <- as.character(tclvalue(textEntryIDs))            

                             studyDesign <- as.character(tclvalue(rbValue))           
                             patientSimType <- as.character(tclvalue(rbValue2))       

                            # myCovariatesNames <- as.character(tclvalue(textEntryCovariatesNames)) 
                            # myDataset  <- as.character(tclvalue(textEntryDataset)) 
                            # catD  <- as.character(tclvalue(textEntryCatD))         
                            # contD  <- as.character(tclvalue(textEntryContD)) 


                             eval(parse(text=paste("myPatients <-",tclvalue(textEntryPatients))))
                             eval(parse(text=paste("myDoses <-",tclvalue(textEntryDoses))))
                             eval(parse(text=paste("myTimes <-",tclvalue(textEntryTimes))))
                             eval(parse(text=paste("myHeader <-",tclvalue(textEntryIDs))))
                             eval(parse(text=paste("myStudyType <-\"",studyDesign,"\"",sep="")))
                             if (tclvalue(textEntryCovariatesNames)!="") eval(parse(text=paste("myCovariatesNames <-",tclvalue(textEntryCovariatesNames))))
                             eval(parse(text=paste("myDataset <-",tclvalue(textEntryDataset))))
                             if (tclvalue(textEntryCatD)!="") eval(parse(text=paste("catNames <-",tclvalue(textEntryCatD))))
                             if (tclvalue(textEntryContD)!="") eval(parse(text=paste("contNames <-",tclvalue(textEntryContD))))

                             covariatePath <- ifelse(exists("myPath"),  myPath, getwd())



                            if(patientSimType=="Resampling") resamplingPatients(myPatients, myDoses, myTimes, 
                                                                  myStudyType, myHeader, myCovariatesNames, 
                                                                  myDataset, covariatePath = covariatePath, writeFile = TRUE)


                             if(patientSimType=="Multivariate") multivariatePatients(myPatients, myDoses, 
                                                                 myTimes, myStudyType, myHeader, catNames, contNames, 
                                                                 myDataset, covariatePath = covariatePath, writeFile = TRUE) 
          print("Simulation completed!")                         

          }





         myPrev <- function(){

                            # myPatients <- as.numeric(tclvalue(textEntryPatients)) 
                            # myTimes <- as.character(tclvalue(textEntryTimes))        
                            # myDoses <- as.character(tclvalue(textEntryDoses))        
                            # myHeader <- as.character(tclvalue(textEntryIDs))            

                             studyDesign <- as.character(tclvalue(rbValue))           
                             patientSimType <- as.character(tclvalue(rbValue2))       

                            # myCovariatesNames <- as.character(tclvalue(textEntryCovariatesNames)) 
                            # myDataset  <- as.character(tclvalue(textEntryDataset)) 
                            # catD  <- as.character(tclvalue(textEntryCatD))         
                            # contD  <- as.character(tclvalue(textEntryContD)) 


                             eval(parse(text=paste("myPatients <-",tclvalue(textEntryPatients))))
                             eval(parse(text=paste("myDoses <-",tclvalue(textEntryDoses))))
                             eval(parse(text=paste("myTimes <-",tclvalue(textEntryTimes))))
                             eval(parse(text=paste("myHeader <-",tclvalue(textEntryIDs))))
                             eval(parse(text=paste("myStudyType <-\"",studyDesign,"\"",sep="")))
                             if (tclvalue(textEntryCovariatesNames)!="") eval(parse(text=paste("myCovariatesNames <-",tclvalue(textEntryCovariatesNames))))
                             eval(parse(text=paste("myDataset <-",tclvalue(textEntryDataset))))
                             if (tclvalue(textEntryCatD)!="") eval(parse(text=paste("catNames <-",tclvalue(textEntryCatD))))
                             if (tclvalue(textEntryContD)!="") eval(parse(text=paste("contNames <-",tclvalue(textEntryContD))))

                             covariatePath <- ifelse(exists("myPath"),  myPath, getwd())


                             if(patientSimType=="Resampling") myStudyPreview <- resamplingPatients(myPatients, myDoses, myTimes, 
                                                                  myStudyType, myHeader, myCovariatesNames, 
                                                                  myDataset, covariatePath = covariatePath, writeFile = FALSE)


                             if(patientSimType=="Multivariate") myStudyPreview <- multivariatePatients(myPatients, myDoses, 
                                                                 myTimes, myStudyType, myHeader, catNames, contNames, 
                                                                 myDataset, covariatePath = covariatePath, writeFile = FALSE)                          

         fix(myStudyPreview,edit.row.names=FALSE) 
         }



         prev.but <- tk2button(dlg,text="  Dataset preview  ",command=myPrev)
         sim.but     <-tk2button(dlg,text="  Simulate study   ",command=mySim)
         Cancel.but <-tk2button(dlg,text=" Cancel ",command=onCancel)
         

         tkgrid(tklabel(dlg,text="       "))
         tkgrid(prev.but, column=1,columnspan=1,row=17, rowspan=1)
         tkgrid(sim.but, column=3,columnspan=1,row=17, rowspan=1)
         tkgrid(Cancel.but, column=4,columnspan=1,row=17, rowspan=1)

         tkgrid(tklabel(dlg,text="       "))



#########################  Tooltips
  tk2tip(patTkLabel, message="Number of subjects in the trials \n\nAllows a single numeric value")
  tk2tip(timeTkLabel, message="Sampling times \n\nAllows a vector in R code (e.g. seq(0,420,7))")
  tk2tip(doseTkLabel, message="Doses to simulate \n\nAllows a vector in R code (e.g. c(0,100,200))")
  tk2tip(IDsTkLabel, message="Header of the ID column \n\nAllows a character string (e.g. \"ID\")")
  tk2tip(covTkLabel, message="Vector containing the headers of the covariates to resample \n\nRequested only if \"Resampling\" is selected")
  tk2tip(datasetTkLabel, message="Name of the dataset .csv where covariates must be resampled")
  tk2tip(catDTkLabel, message="Vector containing the header of the categorical covariates to simulate \n\nRequested only if \"Multivariate\" is selected")
  tk2tip(contDTkLabel, message="Vector containing the header of the categorical covariates to simulate \n\nRequested only if \"Multivariate\" is selected")




tkfocus(dlg)
invisible(tkwm.deiconify(dlg))

}

