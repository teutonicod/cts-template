multivariatePatients <-
function(myPatients=100,myDoses=0,myTimes,myStudyType,myHeader="ID",
                       catNames=NULL,contNames=NULL,myDataset,covariatePath=getwd(),writeFile=TRUE,newDatasetName="myTrial.csv",tol=0.05){ 

                       require(MSToolkit)
                       myPath <- getwd()
                       setwd(covariatePath)
                       d <- read.csv(myDataset)
                       setwd(myPath)

                       dNames <- names(d)
                       dNames[dNames%in%myHeader] <- "ID"
                       names(d) <- dNames
                       pos <- match(unique(d[,names(d)%in%"ID"]),d[,names(d)%in%"ID"])
              
                       d <- d[pos,]
                       if (!is.null(catNames)){
                                   catD <- as.data.frame(d[,dNames%in%catNames])
                                   names(catD) <- dNames[dNames%in%catNames]}
                       
                       if (!is.null(contNames)){
                                   contD <- as.data.frame(d[,dNames%in%contNames])
                                   names(contD) <- dNames[dNames%in%contNames]}
 
                       if (is.null(catNames)&length(contNames)!=1) 
                                   myCovariates <- covMultivarDist(contD=contD,nSub=myPatients,tol=tol)

                       if (is.null(catNames)&length(contNames)==1){

                                   repeate.simulation <- TRUE
                                   while(repeate.simulation){
                                                            logContD <- log(contD)
                                                            logContDmean <- apply(logContD,2,mean,na.rm = TRUE)
                                                            logContDsd <- apply(logContD,2,sd,na.rm = TRUE)
                                                            logMyCovariates <- as.data.frame(rnorm(n=myPatients, mean=logContDmean, sd=logContDsd))
                                                            myCovariates <- exp(logMyCovariates)
                                                            names(myCovariates) <- names(contD)

                                                            minSimCont <- lapply(myCovariates,min,na.rm=TRUE)
                                                            minRealCont <- lapply(contD,min,na.rm=TRUE)
                                                            minCond <- unlist(minSimCont) - unlist(minRealCont) > 0 
                                        
                                                            maxSimCont <- lapply(myCovariates,max,na.rm=TRUE)
                                                            maxRealCont <- lapply(contD,max,na.rm=TRUE)
                                                            maxCond <- unlist(maxSimCont) - unlist(maxRealCont) < 0 
                                                                                
                                                            contCond <- c(minCond,maxCond)

                                                            if (all(contCond)) repeate.simulation <- FALSE
                                                            }
                                   }

                       if (is.null(contNames)&length(catNames)!=1) 
                                   myCovariates <- covMultivarDist(catD=catD,nSub=myPatients,tol=tol)
                       if (is.null(contNames)&length(catNames)==1)
                                    stop(" ERROR from the function multivariatePatients(): \nThe function cannot be used to simulate only one categorical covariate")
                       if (!is.null(contNames) & !is.null(catNames)) 
                                   myCovariates <- covMultivarDist(catD=catD,contD=contD,nSub=myPatients,tol=tol)
                       if (is.null(contNames) & is.null(catNames)) 
                                   stop(" ERROR from the function multivariatePatients(): \nAt least a vector of covariates must be provided")

                       myCovariates$ID <- 1:myPatients
 
                       myTreatments <- length(myDoses)

                       myCreateTreatment <- createTreatments(doses = myDoses, times = myTimes, type= myStudyType)

                       myAllocateTreatment <- allocateTreatments(trts = myTreatments, subjects = myPatients, ordered = FALSE, idCol = "ID")

                       myTrial <- merge(myAllocateTreatment, myCreateTreatment, by="TRT")

                       myTrial <- merge(myTrial, myCovariates, by="ID")

                       myTrial <- myTrial[order(myTrial$ID,myTrial$TIME,myTrial$DOSE),]

                       if (writeFile) {
                                     write.csv(myTrial, newDatasetName, row.names = FALSE, quote = FALSE)
                                     }
                       else return(myTrial)

}

